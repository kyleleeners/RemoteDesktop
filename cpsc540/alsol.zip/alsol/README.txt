Running the main.jl first fill will load necessary packages
