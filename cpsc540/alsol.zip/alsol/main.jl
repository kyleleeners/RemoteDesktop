using Pkg
Pkg.add("JLD")
Pkg.add("PyPlot")
Pkg.build("HDF5")
